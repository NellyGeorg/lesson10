//alert("JS rocks!");

//strings

var myString = "lisa";
var myFavNumber = 13;
var myBoolean = true;

console.log("Name: " + myString);
console.log("Lucky Number: " + myFavNumber);
console.log("Nice weather? " + myBoolean);

/*Fun fact: We can log multiple things at once by separating them with commas, like this:*/

console.log('dog', 'cat', 'bird');


//math
console.log('floats', 3.5);
console.log(2017 - 1917);
console.log(60/2);
console.log(0.2*100);

//modulus examples

var x = 5;
var y = 2;
var z = x % y;
console.log(z);

//or
console.log(13%6);

//math.random 
/*Math.random will generate a random number between 0 and 1.
We then multiplied that number by 50, so now we have a number between 0 and 50.
Then, Math.floor will round the number down to the nearest whole number.*/

console.log(Math.floor(Math.random()*20)); //try several times to see random numbers